package com.hotel.inventoryService.controller;

import com.hotel.inventoryService.dto.InventoryItemDTO;
import com.hotel.inventoryService.model.InventoryItem;
import com.hotel.inventoryService.service.InventoryService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inventory")
public class InventoryController {

    private final InventoryService inventoryService;

    public InventoryController(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }

    @PostMapping
    public InventoryItem createItem(@RequestBody InventoryItemDTO dto) {
        return inventoryService.createItem(dto);
    }

    @GetMapping
    public List<InventoryItem> getAllItems() {
        return inventoryService.getAllItems();
    }

    @GetMapping("/{id}")
    public InventoryItem getItem(@PathVariable Long id) {
        return inventoryService.getItemById(id);
    }

    @PutMapping("/{id}")
    public InventoryItem updateItem(@PathVariable Long id, @RequestBody InventoryItemDTO dto) {
        return inventoryService.updateItem(id, dto);
    }
}
