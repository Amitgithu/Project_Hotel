package com.hotel.inventoryService.repository;

import com.hotel.inventoryService.model.InventoryItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InventoryRepository extends JpaRepository<InventoryItem, Long> {
}
