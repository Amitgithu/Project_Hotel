package com.hotel.inventoryService.service;

import com.hotel.inventoryService.dto.InventoryItemDTO;
import com.hotel.inventoryService.exception.ResourceNotFoundException;
import com.hotel.inventoryService.model.InventoryItem;
import com.hotel.inventoryService.repository.InventoryRepository;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventoryServiceImpl implements InventoryService {

    private final InventoryRepository inventoryRepository;
    private final ModelMapper modelMapper;

    public InventoryServiceImpl(InventoryRepository inventoryRepository, ModelMapper modelMapper) {
        this.inventoryRepository = inventoryRepository;
        this.modelMapper = modelMapper;
    }

    public InventoryItem createItem(InventoryItemDTO dto) {
        return inventoryRepository.save(modelMapper.map(dto, InventoryItem.class));
    }

    public List<InventoryItem> getAllItems() {
        return inventoryRepository.findAll();
    }

    public InventoryItem getItemById(Long id) {
        return inventoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Inventory item not found with id " + id));
    }

    public InventoryItem updateItem(Long id, InventoryItemDTO dto) {
        InventoryItem item = getItemById(id);
        item.setItemName(dto.getItemName());
        item.setCategory(dto.getCategory());
        item.setQuantity(dto.getQuantity());
        item.setThresholdLevel(dto.getThresholdLevel());
        return inventoryRepository.save(item);
    }
}
