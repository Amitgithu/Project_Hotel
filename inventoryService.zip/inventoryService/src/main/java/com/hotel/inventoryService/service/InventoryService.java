package com.hotel.inventoryService.service;

import com.hotel.inventoryService.dto.InventoryItemDTO;
import com.hotel.inventoryService.model.InventoryItem;

import java.util.List;

public interface InventoryService {
    InventoryItem createItem(InventoryItemDTO dto);
    List<InventoryItem> getAllItems();
    InventoryItem getItemById(Long id);
    InventoryItem updateItem(Long id, InventoryItemDTO dto);
}
