package com.hotel.roomService.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "rooms")
public class Room {

    @Id
    @GeneratedValue
    private Long roomId;

    @Column(nullable = false, unique = true)
    private String roomNumber;

    private String roomType;  // No enum, just String like "Single", "Double", "Suite", etc.

    private boolean isAvailable; // true = available, false = booked

    @Column(nullable = false)
    private BigDecimal pricePerNight;

    @CreationTimestamp
    private Instant createdAt;
}
