package com.hotel.bookingService.service.impl;

import com.hotel.bookingService.dto.BookingDTO;
import com.hotel.bookingService.exception.ResourceNotFoundException;
import com.hotel.bookingService.model.Booking;
import com.hotel.bookingService.model.BookingStatus;
import com.hotel.bookingService.repository.BookingRepository;
import com.hotel.bookingService.service.imple.BookingServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class BookingServiceImplTest {

    @Mock
    private BookingRepository bookingRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private BookingServiceImpl bookingServiceImpl;

    private Booking booking;
    private BookingDTO bookingDTO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        booking = new Booking();
        booking.setBookingId(1L);
        booking.setCheckinDate(LocalDate.of(2024, 7, 10));
        booking.setCheckoutDate(LocalDate.of(2024, 7, 15));
        booking.setNumGuests(2);
        booking.setBookingStatus(BookingStatus.BOOKED);
        booking.setCreatedAt(LocalDateTime.now());

        bookingDTO = new BookingDTO();
        bookingDTO.setBookingId(1L);
        booking.setCheckinDate(LocalDate.of(2024, 7, 10));
        booking.setCheckoutDate(LocalDate.of(2024, 7, 15));
        bookingDTO.setNumGuests(2);
    }

    @Test
    void testCreateBooking() {
        when(modelMapper.map(any(BookingDTO.class), eq(Booking.class))).thenReturn(booking);
        when(bookingRepository.save(any(Booking.class))).thenReturn(booking);
        when(modelMapper.map(any(Booking.class), eq(BookingDTO.class))).thenReturn(bookingDTO);

        BookingDTO createdBooking = bookingServiceImpl.createBooking("Standard", bookingDTO);

        assertNotNull(createdBooking);
        assertEquals(2, createdBooking.getNumGuests());
        verify(bookingRepository, times(1)).save(any(Booking.class));
    }

    @Test
    void testGetBookingById_Success() {
        when(bookingRepository.findById(1L)).thenReturn(Optional.of(booking));
        when(modelMapper.map(booking, BookingDTO.class)).thenReturn(bookingDTO);

        BookingDTO result = bookingServiceImpl.getBookingById(1L);

        assertNotNull(result);
        assertEquals(2, result.getNumGuests());
    }

    @Test
    void testGetBookingById_NotFound() {
        when(bookingRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> bookingServiceImpl.getBookingById(1L));
    }

    @Test
    void testGetAllBookings() {
        when(bookingRepository.findAll()).thenReturn(Arrays.asList(booking));
        when(modelMapper.map(any(Booking.class), eq(BookingDTO.class))).thenReturn(bookingDTO);

        List<BookingDTO> bookings = bookingServiceImpl.getAllBookings();

        assertEquals(1, bookings.size());
        verify(bookingRepository, times(1)).findAll();
    }

    @Test
    void testUpdateBooking_Success() {
        when(bookingRepository.findById(1L)).thenReturn(Optional.of(booking));
        when(bookingRepository.save(any(Booking.class))).thenReturn(booking);
        when(modelMapper.map(any(Booking.class), eq(BookingDTO.class))).thenReturn(bookingDTO);

        BookingDTO updatedBooking = bookingServiceImpl.updateBooking(1L, bookingDTO);

        assertNotNull(updatedBooking);
        assertEquals(2, updatedBooking.getNumGuests());
        verify(bookingRepository, times(1)).save(any(Booking.class));
    }

    @Test
    void testUpdateBooking_NotFound() {
        when(bookingRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> bookingServiceImpl.updateBooking(1L, bookingDTO));
    }

    @Test
    void testDeleteBooking_Success() {
        when(bookingRepository.findById(1L)).thenReturn(Optional.of(booking));
        doNothing().when(bookingRepository).delete(booking);

        bookingServiceImpl.deleteBooking(1L);

        verify(bookingRepository, times(1)).delete(booking);
    }

    @Test
    void testDeleteBooking_NotFound() {
        when(bookingRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> bookingServiceImpl.deleteBooking(1L));
    }
}
