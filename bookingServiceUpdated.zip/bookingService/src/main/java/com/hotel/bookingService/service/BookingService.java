package com.hotel.bookingService.service;

import com.hotel.bookingService.dto.BookingDTO;
import java.util.List;

public interface BookingService {


    BookingDTO getBookingById(Long bookingId);

    List<BookingDTO> getAllBookings();

    BookingDTO updateBooking(Long bookingId, BookingDTO bookingDTO);

    void deleteBooking(Long bookingId);
    BookingDTO createBooking(String roomType, BookingDTO bookingDTO);

}
