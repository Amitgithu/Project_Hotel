package com.hotel.bookingService.service.imple;

import com.hotel.bookingService.dto.BookingDTO;
import com.hotel.bookingService.dto.GuestRequestDTO;
import com.hotel.bookingService.dto.GuestResponseDTO;
import com.hotel.bookingService.dto.RoomResponseDto;
import com.hotel.bookingService.model.Booking;
import com.hotel.bookingService.model.BookingStatus;
import com.hotel.bookingService.exception.ResourceNotFoundException;
import com.hotel.bookingService.model.Guest;
import com.hotel.bookingService.repository.BookingRepository;
import com.hotel.bookingService.repository.GuestRepository;
import com.hotel.bookingService.service.BookingService;
import com.hotel.bookingService.service.RoomServiceClient;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BookingServiceImpl implements BookingService {

    @Autowired
    private  BookingRepository bookingRepository;

    @Autowired
    private  ModelMapper modelMapper;

    @Autowired
    private GuestRepository guestRepository;

    @Autowired
    private GuestServiceImpl guestService;

    @Autowired
    private RoomServiceClient roomServiceClient;

    @Override
    public BookingDTO createBooking(String roomType, BookingDTO bookingDTO) {
        // 1. Get available room by type
        RoomResponseDto room = roomServiceClient.getAvailableRoomByType(roomType);

        if (room == null || !room.isAvailable()) {
            throw new RuntimeException("No available room of type: " + roomType);
        }

        // 2. Creating Guest
        GuestRequestDTO guestDetail = bookingDTO.getGuest();
        if (guestDetail == null) {
            throw new RuntimeException("Guest details are missing.");
        }

        GuestResponseDTO guestResponse = guestService.createGuest(guestDetail);
        Guest guestCreated = modelMapper.map(guestResponse, Guest.class);

        System.out.println("Saved guest ID: " + guestCreated.getGuestId());


        // 3. Set booking details
        Booking booking = new Booking();
        booking.setRoomId(room.getRoomId());
        booking.setGuestId(guestCreated.getGuestId());
        booking.setBookingStatus(BookingStatus.BOOKED);
        booking.setCheckinDate(bookingDTO.getCheckinDate());
        booking.setCheckoutDate(bookingDTO.getCheckoutDate());
        booking.setNumGuests(bookingDTO.getNumGuests());
        booking.setCreatedAt(LocalDateTime.now());

        bookingRepository.save(booking);


        // 3. Update room availability in RoomService
        roomServiceClient.updateRoomAvailability(room.getRoomId(), false);

        // 4. Return response
        bookingDTO.setRoomId(room.getRoomId());
        return bookingDTO;
    }

    @Override
    public BookingDTO getBookingById(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id: " + bookingId));
        return modelMapper.map(booking, BookingDTO.class);
    }

    @Override
    public List<BookingDTO> getAllBookings() {
        List<Booking> bookings = bookingRepository.findAll();
        return bookings.stream()
                .map(booking -> modelMapper.map(booking, BookingDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public BookingDTO updateBooking(Long bookingId, BookingDTO bookingDTO) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id: " + bookingId));

        booking.setCheckinDate(bookingDTO.getCheckinDate());
        booking.setCheckoutDate(bookingDTO.getCheckoutDate());
        booking.setNumGuests(bookingDTO.getNumGuests());
        booking.setUpdatedAt(LocalDateTime.now());

        Booking updatedBooking = bookingRepository.save(booking);
        return modelMapper.map(updatedBooking, BookingDTO.class);
    }

    @Override
    public void deleteBooking(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id: " + bookingId));
        bookingRepository.delete(booking);
    }
}
