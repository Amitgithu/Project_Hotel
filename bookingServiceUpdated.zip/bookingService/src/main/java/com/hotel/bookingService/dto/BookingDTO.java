package com.hotel.bookingService.dto;

import com.hotel.bookingService.model.Guest;
import lombok.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BookingDTO {

    private Long bookingId; // Only for reading

    @NotNull(message = "Guest detail is mandatory")
    private GuestRequestDTO guest;

    @NotNull(message = "Room ID is mandatory")
    private Long roomId;

    @NotNull(message = "Check-in date is required")
    private LocalDate checkinDate;

    @NotNull(message = "Check-out date is required")
    private LocalDate checkoutDate;

    @NotNull(message = "Number of guests is required")
    @Min(1)
    private Integer numGuests;

    private String bookingStatus; // Booked by default
}
