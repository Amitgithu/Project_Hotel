package com.example.apigatewayservice.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;

@Component
public class JwtUtil {

    private static final SecretKey SECRET_KEY = Keys.hmacShaKeyFor("nVX7PbKwO5NsMwFQWxIyQJZ3ZtE3Z2m9IV3TrxTiMI4=".getBytes());

    // Validate JWT Token
    public void validateToken(final String token) {
        Jwts.parser()
                .verifyWith(SECRET_KEY) // Correct method without typecasting
                .build()
                .parse(token.replace("Bearer ", ""));
    }

    // Extract Role from JWT Token
    public String extractRole(String token) {
        Claims claims = (Claims) Jwts.parser()
                .verifyWith(SECRET_KEY)
                .build()
                .parse(token.replace("Bearer ", ""))
                .getPayload(); // Correct way to get claims

        System.out.println("Claims: " + claims);

        System.out.println("User Role: " + claims.get("role", String.class));
        return claims.get("role", String.class);
    }

}
