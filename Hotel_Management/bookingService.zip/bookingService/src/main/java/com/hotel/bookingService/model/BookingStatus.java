package com.hotel.bookingService.model;

public enum BookingStatus {
    BOOKED,
    CANCELLED,
    CHECKED_IN,
    CHECKED_OUT
}
