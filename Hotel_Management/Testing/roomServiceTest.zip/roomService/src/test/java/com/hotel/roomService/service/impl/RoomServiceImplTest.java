package com.hotel.roomService.service.impl;

import com.hotel.roomService.dto.RoomRequestDto;
import com.hotel.roomService.dto.RoomResponseDto;
import com.hotel.roomService.exception.ResourceNotFoundException;
import com.hotel.roomService.model.Room;
import com.hotel.roomService.repository.RoomRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RoomServiceImplTest {

    @Mock
    private RoomRepository roomRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private RoomServiceImpl roomServiceImpl;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateRoom() {
        RoomRequestDto requestDto = new RoomRequestDto();
        Room room = new Room();
        Room savedRoom = new Room();
        RoomResponseDto responseDto = new RoomResponseDto();

        when(modelMapper.map(requestDto, Room.class)).thenReturn(room);
        when(roomRepository.save(room)).thenReturn(savedRoom);
        when(modelMapper.map(savedRoom, RoomResponseDto.class)).thenReturn(responseDto);

        RoomResponseDto result = roomServiceImpl.createRoom(requestDto);

        assertNotNull(result);
        verify(roomRepository, times(1)).save(room);
    }

    @Test
    void testGetRoomById_Success() {
        Long roomId = 1L;
        Room room = new Room();
        RoomResponseDto responseDto = new RoomResponseDto();

        when(roomRepository.findById(roomId)).thenReturn(Optional.of(room));
        when(modelMapper.map(room, RoomResponseDto.class)).thenReturn(responseDto);

        RoomResponseDto result = roomServiceImpl.getRoomById(roomId);

        assertNotNull(result);
        verify(roomRepository, times(1)).findById(roomId);
    }

    @Test
    void testGetRoomById_NotFound() {
        Long roomId = 1L;
        when(roomRepository.findById(roomId)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            roomServiceImpl.getRoomById(roomId);
        });
    }

    @Test
    void testGetAllRooms() {
        List<Room> rooms = Arrays.asList(new Room(), new Room());
        when(roomRepository.findAll()).thenReturn(rooms);
        when(modelMapper.map(any(Room.class), eq(RoomResponseDto.class)))
                .thenReturn(new RoomResponseDto());

        List<RoomResponseDto> result = roomServiceImpl.getAllRooms();

        assertEquals(2, result.size());
    }

    @Test
    void testUpdateRoom_Success() {
        Long roomId = 1L;
        RoomRequestDto requestDto = new RoomRequestDto();
        Room existingRoom = new Room();
        Room updatedRoom = new Room();
        RoomResponseDto responseDto = new RoomResponseDto();

        when(roomRepository.findById(roomId)).thenReturn(Optional.of(existingRoom));
        doAnswer(invocation -> null).when(modelMapper).map(eq(requestDto), eq(existingRoom));
        when(roomRepository.save(existingRoom)).thenReturn(updatedRoom);
        when(modelMapper.map(updatedRoom, RoomResponseDto.class)).thenReturn(responseDto);

        RoomResponseDto result = roomServiceImpl.updateRoom(roomId, requestDto);

        assertNotNull(result);
    }

    @Test
    void testUpdateRoom_NotFound() {
        Long roomId = 1L;
        RoomRequestDto requestDto = new RoomRequestDto();

        when(roomRepository.findById(roomId)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            roomServiceImpl.updateRoom(roomId, requestDto);
        });
    }

    @Test
    void testDeleteRoom_Success() {
        Long roomId = 1L;
        Room room = new Room();

        when(roomRepository.findById(roomId)).thenReturn(Optional.of(room));

        roomServiceImpl.deleteRoom(roomId);

        verify(roomRepository, times(1)).findById(roomId);
        verify(roomRepository, times(1)).delete(room);
    }

    @Test
    void testDeleteRoom_NotFound() {
        Long roomId = 1L;
        when(roomRepository.findById(roomId)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            roomServiceImpl.deleteRoom(roomId);
        });
    }
}
